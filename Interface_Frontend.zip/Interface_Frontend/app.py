from flask import Flask, render_template, request, redirect, url_for
import os
import cv2
from ultralytics import YOLO

# Initialize Flask app
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Load YOLOv8 model
model = YOLO('models/best.pt')  # Update the path to your trained YOLOv8 model

# Home route
@app.route('/')
def index():
    return render_template('index.html')

# Detection route
@app.route('/detect', methods=['POST'])
def detect():
    if 'image' not in request.files:
        return redirect(request.url)
    
    file = request.files['image']
    if file.filename == '':
        return redirect(request.url)

    # Save the uploaded image
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    # Run detection on the uploaded image
    results = model(filepath)
    labels = results[0].names  # Get class names
    detected_classes = [labels[int(cls)] for cls in results[0].boxes.cls]

    # Annotate the image with detections
    annotated_image = results[0].plot()
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], f'output_{file.filename}')
    cv2.imwrite(output_path, annotated_image)

    # Pass the results to the frontend
    return render_template('index.html', uploaded_image=filepath, output_image=output_path, detections=detected_classes)

if __name__ == '__main__':
    app.run(debug=True)
